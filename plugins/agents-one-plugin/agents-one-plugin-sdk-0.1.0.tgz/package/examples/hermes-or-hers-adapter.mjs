/**
 * Skeleton for a Hermes Dashboard / Hers Relay adapter.
 * Feed completed Dashboard events into `emit`; do not forward raw thoughts.
 */
export function mapHermesEvent(source) {
  if (source.kind === "thought" && source.summary) {
    return { id: source.id, type: "reasoning.summary", data: { reasoningSummary: source.summary } };
  }
  if (source.kind === "tool") {
    return {
      id: source.id,
      type: source.status === "failed" ? "tool.failed" : "tool.completed",
      data: { tool: { kind: source.mcp ? "mcp" : source.skill ? "skill" : "tool", name: source.name, outputSummary: source.summary } },
    };
  }
  if (source.kind === "assistant" && source.final) {
    return { id: source.id, type: "assistant.completed", data: { text: source.text } };
  }
  return undefined;
}
